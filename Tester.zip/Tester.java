import java.util.ArrayList;
import java.util.Scanner;

class BloodPressure {
    private int id;
    private String name;
    private int yob;
    private int systolic;
    private int diastolic;

    public BloodPressure(int id, String name, int yob, int systolic, int diastolic) {
        this.id = id;
        this.name = name;
        this.yob = yob;
        this.systolic = systolic;
        this.diastolic = diastolic;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getYob() {
        return yob;
    }

    public int getSystolic() {
        return systolic;
    }

    public int getDiastolic() {
        return diastolic;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setYob(int yob) {
        this.yob = yob;
    }

    public void setSystolic(int systolic) {
        this.systolic = systolic;
    }

    public void setDiastolic(int diastolic) {
        this.diastolic = diastolic;
    }

    public int calculateAge() {
        int currentYear = 2024;
        return currentYear - yob;
    }

    public String getBloodPressureCategory() {
        int systolicReading = getSystolic();
        int diastolicReading = getDiastolic();

        if (systolicReading < 120 && diastolicReading < 80) {
            return "Normal";
        } else if (systolicReading >= 120 && systolicReading <= 129 && diastolicReading < 80) {
            return "Elevated";
        } else if ((systolicReading >= 130 && systolicReading <= 139)
                || (diastolicReading >= 80 && diastolicReading <= 89)) {
            return "Hypertension Stage 1";
        } else if (systolicReading >= 140 || diastolicReading >= 90) {
            return "Hypertension Stage 2";
        } else {
            return "Hypertensive crisis (requires medical attention)";
        }
    }

    public void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Year of Birth: " + yob);
        System.out.println("Systolic Blood Pressure: " + systolic);
        System.out.println("Diastolic Blood Pressure: " + diastolic);
        System.out.println("Age: " + calculateAge());
        System.out.println("Blood Pressure Category: " + getBloodPressureCategory());
    }
}

public class Tester {
    private static ArrayList<BloodPressure> records = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    private static BloodPressure createRecord() {
        System.out.print("Enter ID: ");
        int id = scanner.nextInt();
        System.out.print("Enter Name: ");
        String name = scanner.next();
        System.out.print("Enter Year of Birth: ");
        int yob = scanner.nextInt();
        System.out.print("Enter Systolic Blood Pressure: ");
        int systolic = scanner.nextInt();
        System.out.print("Enter Diastolic Blood Pressure: ");
        int diastolic = scanner.nextInt();
        return new BloodPressure(id, name, yob, systolic, diastolic);
    }

    private static void displayAllRecords() {
        System.out.println("All Blood Pressure Records:");
        System.out.println("--------------------");
        for (BloodPressure record : records) {
            record.display();
            System.out.println("--------------------");
        }
    }

    private static void viewRecordById() {
        System.out.print("Enter ID to view record: ");
        int id = scanner.nextInt();
        boolean found = false;
        for (BloodPressure record : records) {
            if (record.getId() == id) {
                record.display();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("No record found for ID: " + id);
        }
    }

    private static void deleteAllRecords() {
        records.clear();
        System.out.println("All Blood Pressure Records deleted successfully.");
    }

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println(" Blood Pressure Monitor");
            System.out.println("-----------------------");
            System.out.println("1. Create a record.");
            System.out.println("2. Show all records.");
            System.out.println("3. View record by ID.");
            System.out.println("4. Delete all records.");
            System.out.println("5. Exit application.");
            System.out.println("-----------------------");
            System.out.print("Enter Your Choice: ");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    for (int j = 0; j < 5; j++) {
                        BloodPressure newRecord = createRecord();
                        records.add(newRecord);
                        System.out.println("---------------------");
                    }
                    break;
                case 2:
                    System.out.println("--------------------");
                    displayAllRecords();
                    break;
                case 3:
                    System.out.println("--------------------");
                    viewRecordById();
                    break;
                case 4:
                    System.out.println("--------------------");
                    deleteAllRecords();
                    break;
                case 5:
                    System.out.println("Thank you for using the Blood Pressure Monitor.");
                    break;
                default:
                    System.out.println("Invalid Choice.");
            }
        } while (choice != 5);
    }
}